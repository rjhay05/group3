const mongoose=require('mongoose')

const blogSchema=mongoose.Schema(
{



})