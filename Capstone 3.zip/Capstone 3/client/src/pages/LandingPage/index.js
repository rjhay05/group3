
import './index.css'
function LandingPage(){
    return(
      <div>
      <div className="menu container">    
          <div className="logo">
              <h4>LOGO</h4>
          </div>
          <div className="btn-container ms-auto">
              <button className="login-btn text-light">Login</button>
          </div>
      </div>
    <section id="particles-js" class="hero">
      <div class="hero-content">
        <div class="hero-heading">
          <h2>DEVELOP AND BLOG AT</h2>
          <h1>DEVLOG</h1>
        </div>

        <div>
          <button class="hero-btn text-light">Start your blog</button>
        </div>
        <div class="icon-scroll"></div>
      </div>
    </section>

      {/* <!-- section 2 --> */}
      <section id="post-1" className="entry-holder blog-item-holder has-post-thumbnail">
          <div className="entry-content relative">
              <div className="content-1170 center-relative center-text">
              <h2 className="entry-title">
                  Developing and Blogging Is A Never Ending Story
              </h2>
              </div>
          </div>
      </section>
      {/* <!-- end of section2 --> */}

      <section id="post-2" className="entry-holder blog-item-holder">
          <div className="entry-content relative">
              <div className="content-1170 center-relative center-text">
              <h1 className="entry-title">
                  Start sharing your experience with us and to our fellow developers
              </h1>
              </div>
          </div>
      </section>

      <section id="post-3" className="entry-holder blog-item-holder">
          <div className="entry-content relative">
              <div className="content-1170 center-relative center-text">
              <h1 className="entry-title">
                  Start sharing your experience with us and to our fellow developers
              </h1>
              </div>
          </div>
      </section>
          <div className="">
              {/* <!-- Footer --> */}
              <footer className="text-center text-lg-start text-white" >
                  <div className="container p-4 pb-0">
                      <section className="">
                          <div className="row">
                              <div className="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
                                  <h6 className="text-uppercase mb-4 font-weight-bold">Contact</h6>
                                  <p><i className="fas fa-home mr-3"></i> New York, NY 10012, US</p>
                                  <p><i className="fas fa-envelope mr-3"></i> info@gmail.com</p>
                                  <p><i className="fas fa-phone mr-3"></i> + 01 234 567 88</p>
                                  <p><i className="fas fa-print mr-3"></i> + 01 234 567 89</p>
                              </div>
                          </div>
      </section>
      <hr className="my-3" />

      <section className="p-3 pt-0">
        <div className="row d-flex align-items-center">
          <div className="col-md-7 col-lg-8 text-center text-md-start">
            <div className="p-3">
              © 2022 Copyright:
              <a className="text-white" href="https://mdbootstrap.com/">GRIT</a>
            </div>
          </div>
         
          <div className="col-md-5 col-lg-4 ml-lg-0 text-center text-md-end">
           
            <a className="btn btn-outline-light btn-floating m-1 text-white" role="button">
            <i className="fab fa-facebook-f"></i></a>

            
            <a className="btn btn-outline-light btn-floating m-1 text-white" role="button">
            <i className="fab fa-twitter"></i></a>

       
            <a className="btn btn-outline-light btn-floating m-1 text-white" role="button">
            <i className="fab fa-google"></i></a>

       
            <a className="btn btn-outline-light btn-floating m-1 text-white" role="button">
            <i className="fab fa-instagram"></i></a>
          </div>
        
        </div>
      </section>
    </div>
  </footer>
</div>
</div>
    )
}

export default LandingPage;